const healer = extend(ItemTurret, "纳米风暴", {
})
healer.buildType = prov(() => new JavaAdapter(ItemTurret.ItemTurretBuild, {
	collide(other) { return other.owner != this },
    findTarget() {
        var target = Units.findDamagedTile(this.team, this.x, this.y)
        if (target != null && target != this && this.dst(target) <= healer.range) {
            this.target = target;
        } else {
            this.super$findTarget();
        }
    },
    validateTarget() {
        return !Units.invalidateTarget(this.target, Team.derelict, this.x, this.y) || this.isControlled() || this.logicControlled();
    },
}, healer))