MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("方块/纳米风暴");
require("方块/前哨基地");
require("方块/最高指挥中心");
require("工厂/灌注站");
require("工厂/倾倒站");
require("工厂/螺旋压缩机");
require("星球/泰伯利亚");
require("物品");
require("液体");